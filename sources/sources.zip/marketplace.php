<?php 
include("themes/$currentTheme/layouts/marketplace.php"); 
?>