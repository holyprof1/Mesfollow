<?php 
  include("themes/$currentTheme/purchase_point.php");   
?>