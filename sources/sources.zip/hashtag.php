<?php   
include("themes/$currentTheme/hashtag.php");  
?> 