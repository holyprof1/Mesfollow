<?php 
include("themes/$currentTheme/maintenance.php"); 
?>