<?php   
include("themes/$currentTheme/post.php");   
?> 