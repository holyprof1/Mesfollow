<?php 
include("themes/$currentTheme/layouts/creators.php"); 
?>