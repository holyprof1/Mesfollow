<?php 
include("themes/$currentTheme/404.php"); 
?>