<?php   
include("themes/$currentTheme/product.php");   
?> 