<div class="i_welcomebox">
   <div class="i_welcomebox_in">
      <div class="i_welcomebox_title"><?php echo iN_HelpSecure($LANG['welcome_to']);?></div>
      <div class="i_welcomebox_slogan"><?php echo html_entity_decode($LANG['signup_for']);?></div>
      <div class="i_welcomebox_login_signup">
         <div class="i_login loginForm"><?php echo iN_HelpSecure($LANG['login']);?></div>
         <a href="<?php echo iN_HelpSecure($base_url);?>register"><div class="i_singup"><?php echo iN_HelpSecure($LANG['sign_up']);?></div></a>
      </div>
   </div>
</div>
<div class="i_register"><a class="loginForm"><?php echo iN_HelpSecure($LANG['moniteize_your_content']);?></a></div>