<div class="i_message_wrpper">
<a href="<?php echo iN_HelpSecure($profileUrl);?>">
<div class="i_message_wrapper transition">
    <div class="i_message_owner_avatar">
        <div class="i_message_avatar"><img src="<?php echo iN_HelpSecure($resultUserAvatar);?>" alt="<?php echo iN_HelpSecure($resultUserFullName);?>"></div>
    </div>
    <div class="i_message_info_container">
        <div class="i_message_owner_name"><?php echo iN_HelpSecure($resultUserFullName);?></div>
    </div>
</div>
</a>
</div>