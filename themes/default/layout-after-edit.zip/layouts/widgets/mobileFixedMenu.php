<div class="mobile_footer_fixed_menu_container">
    <div class="mobile_fixed_box_wrapper flex_ tabing">
        <div class="mobile_box">
            <a href="<?php echo filter_var($base_url, FILTER_VALIDATE_URL);?>"><div class="i_m_box_item transition flex_ tabing"><?php echo html_entity_decode($iN->iN_SelectedMenuIcon('99'));?></div></a>
        </div>
        <div class="mobile_box fms">
            <div class="i_m_box_item transition mobile_srcbtn flex_ tabing"><?php echo html_entity_decode($iN->iN_SelectedMenuIcon('101'));?></div>
        </div>
        <div class="mobile_box">
            <a href="<?php echo filter_var($base_url, FILTER_VALIDATE_URL);?>creators"><div class="i_m_box_item transition flex_ tabing"><?php echo html_entity_decode($iN->iN_SelectedMenuIcon('95'));?></div></a>
        </div>
        <div class="mobile_box">
            <a href="<?php echo filter_var($base_url, FILTER_VALIDATE_URL);?>live_streams?live=paid"><div class="i_m_box_item transition flex_ tabing"><?php echo html_entity_decode($iN->iN_SelectedMenuIcon('180'));?></div></a>
        </div>
        <div class="mobile_box">
            <a href="<?php echo filter_var($base_url, FILTER_VALIDATE_URL);?>videos"><div class="i_m_box_item transition flex_ tabing"><?php echo html_entity_decode($iN->iN_SelectedMenuIcon('181'));?></div></a>
        </div>
        <div class="mobile_box">
            <a href="<?php echo filter_var($base_url, FILTER_VALIDATE_URL).$userName;?>"><div class="i_m_box_item transition flex_ tabing"><?php echo html_entity_decode($iN->iN_SelectedMenuIcon('83'));?></div></a>
        </div>
        </div>
</div>